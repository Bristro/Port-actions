## Send a Slack/Teams message whenever a scorecard rule result is **updated**
   
### Pre-requisites:

#### Webhook URLs

The workflow requires a Slack webhook URL and/or a Microsoft Teams webhook URL to send the message.  

 **Slack**:
 1. To set up a Slack webhook, follow the instructions [here](https://api.slack.com/messaging/webhooks).
 2. Once you have the webhook URL, add it as a secret in your GitHub repository named `SLACK_WEBHOOK_URL`.

 **Microsoft Teams**:
 1. To set up a Microsoft Teams webhook, follow the instructions [here](https://learn.microsoft.com/en-us/microsoftteams/platform/webhooks-and-connectors/how-to/add-incoming-webhook).
 2. Once you have the webhook URL, add it as a secret in your GitHub repository named `TEAMS_WEBHOOK_URL`.



